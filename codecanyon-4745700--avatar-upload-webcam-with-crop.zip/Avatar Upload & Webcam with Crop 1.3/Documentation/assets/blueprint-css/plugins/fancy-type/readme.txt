Fancy Type

* Gives you classes to use if you'd like some 
  extra fancy typography. 

Credits and instructions are specified above each class
in the fancy-type.css file in this directory.


Usage
----------------------------------------------------------------

1) Add this plugin to lib/settings.yml.
   See compress.rb for instructions.
