<?php
	//Start session
	session_start();
	//include config file
	require_once('config.php');

	//Check if a user avatar session exists, otherwise set a default avatar image
	if (!empty($_SESSION['user_avatar'])) {
		$user_avatar = $_SESSION['user_avatar'];
	} else {
		$user_avatar = 'assets/images/avatar.jpg';
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Avatar Upload / Webcam with Crop</title>
	<!-- CSS files -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<!-- JavaScript files -->
	<script type="text/javascript" src="assets/js/jquery-1.8.1.min.js"></script>
	<script type="text/javascript" src="assets/js/ajaxupload.3.5.js"></script>
	<script type="text/javascript" src="assets/js/jquery.imgareaselect.min.js"></script>
	<script type="text/javascript" src="assets/webcam/webcam.js"></script>
	<script type="text/javascript" src="assets/js/script.js?v=1.1"></script>
</head>
<body>
	<!-- BEGIN CONTAINER -->
	<div class="container">
		<div class="thumbnail pull-right user-avatar">
			<img src="<?php echo $user_avatar; ?>" width="70" height="70" style="width:70px; height:70px;">
		</div>

		<h3>Avatar Upload / Webcam with Crop</h3>

		<div class="btn-group">
		  <button type="button" class="btn btn-small" id="uploadimage">Upload Image</button>
		  <button type="button" class="btn btn-small" onclick="webcamSnapshot()">Webcam Snapshot</button>
		</div>
		
		<!-- BEGIN UPLOAD CONTAINER -->
		<div id="upload_container" class="hidden">
			<div class="alert hidden"> <button type="button" class="close" data-dismiss="alert">&times;</button> <span></span> </div>
			<div class="crop">
			</div>
		</div>
		<!-- end div #upload_container -->
		
		<!-- BEGIN UPLOAD CONTAINER -->
		<div id="webcam_container" class="hidden">
			<div class="alert hidden"> <button type="button" class="close" data-dismiss="alert">&times;</button> <span></span> </div>
			<p id="webcam">
			</p>
			<div class="crop">
			</div>
			<p class="controls">
				<button type="button" class="btn btn-small cancel"> <i class="icon-remove"></i> Cancel</button>
				<button class="btn btn-primary btn-small" onClick="webcam.snap()"> <i class="icon-camera icon-white"></i> Take Snapshot</button>
			</p>
		</div>
		<!-- end div #webcam_container -->

		<input type="hidden" name="x1" value="" id="x1" />
		<input type="hidden" name="y1" value="" id="y1" />
		<input type="hidden" name="w" value="" id="w" />
		<input type="hidden" name="h" value="" id="h" />
	<div>
	<!-- end div .container -->
</body>
</html>