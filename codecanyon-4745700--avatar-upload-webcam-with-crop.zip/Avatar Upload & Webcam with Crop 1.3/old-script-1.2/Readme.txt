avatarm  - contains the script
Documentation - contains the documentation for the script

Live Demo: http://demo.hazzardweb.net/avatar/
Live Docs: http://demo.hazzardweb.net/avatar/docs/

For more help contact me here:
	http://codecanyon.net/user/HazzardWeb
	or
	hazzardweb@gmail.com